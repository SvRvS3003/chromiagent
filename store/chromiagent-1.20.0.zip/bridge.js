// Chromiagent bridge, by SvRvS: runs in the side panel and executes the agent's tool calls on any tab.
// Each panel has its own id; the agent started from it is bound to this browser only.
// The id is kept per window for the browser session, so closing and reopening the panel resumes
// the same agent; a new browser session starts fresh.
const panelReady = (async () => {
  const { id: windowId } = await chrome.windows.getCurrent();
  const key = `panel:${windowId}`;
  // Without the storage permission (extension not reloaded after an update) each opening is a new session.
  if (!chrome.storage?.session) return { id: crypto.randomUUID(), windowId };
  const saved = (await chrome.storage.session.get(key))[key];
  if (saved) return { id: saved, windowId };
  const id = crypto.randomUUID();
  await chrome.storage.session.set({ [key]: id });
  return { id, windowId };
})();
// The agent stays inside the web: local files via file:// are refused everywhere.
const noFile = (url) => { if (/^\s*file:/i.test(url || '')) throw new Error('file:// URLs are blocked (Chrome web tasks only)'); };


// ---- in-page helpers (one self-contained function serialized into the tab by chrome.scripting) ----
// One function serves every read/action call so the traversal helpers stay together. It sees open
// shadow roots, same-origin frames, dialogs, popovers and native select options — the places where a
// plain document.querySelectorAll("button,input,...") lost popups and dropdowns.
function pageCmd(cmd, ref, selector, text, submit, dy) {
  const CA_SEL = 'a[href],button,input,textarea,select,summary,[role=button],[role=link],[role=tab],[role=menuitem],[role=checkbox],[role=option],[contenteditable=""],[contenteditable=true],[onclick],[tabindex]:not([tabindex="-1"])';
  const SKIP_TEXT = /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|SVG|PATH)$/;
  const clean = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const shown = (el) => {
    try {
      const r = el.getBoundingClientRect(), st = getComputedStyle(el);
      return r.width >= 1 && r.height >= 1 && st.visibility !== 'hidden' && st.display !== 'none';
    } catch { return false; }
  };
  const labelOf = (el) => clean(el.getAttribute('aria-label') || el.innerText || (el.type === 'password' ? '' : el.value) || el.placeholder || el.title || el.alt || el.name || '').slice(0, 80);
  const kindOf = (el) => el.tagName.toLowerCase() + (el.type ? `:${el.type}` : '') + (el.getAttribute('role') ? `[${el.getAttribute('role')}]` : '');
  const frameDoc = (el) => { try { const d = el.contentDocument; return d && d.body ? d.body : null; } catch { return null; } };
  const walk = (root, fn, depth = 0, prefix = '') => {
    if (depth > 4) return;
    let nodes;
    try { nodes = root.querySelectorAll('*'); } catch { return; }
    for (const el of nodes) {
      fn(el, prefix);
      if (el.shadowRoot) walk(el.shadowRoot, fn, depth + 1, prefix + `shadow#${el.id || el.tagName.toLowerCase()} > `);
      if (el.tagName === 'IFRAME') { const d = frameDoc(el); if (d) walk(d, fn, depth + 1, prefix + `frame#${el.id || ''} > `); }
    }
  };
  const findRef = (root, wanted, depth = 0) => {
    if (depth > 4) return null;
    let nodes;
    try { nodes = root.querySelectorAll('*'); } catch { return null; }
    for (const el of nodes) {
      if (el.getAttribute('data-ca') === String(wanted)) return el;
      if (el.shadowRoot) { const r = findRef(el.shadowRoot, wanted, depth + 1); if (r) return r; }
      if (el.tagName === 'IFRAME') { const d = frameDoc(el); if (d) { const r = findRef(d, wanted, depth + 1); if (r) return r; } }
    }
    return null;
  };
  // A selector may pierce with "host >>> inner"; prefix a part with shadow: or frame: to require it.
  const resolve = () => {
    if (!selector) return findRef(document.body || document.documentElement, ref);
    if (!selector.includes('>>>')) return document.querySelector(selector);
    let root = document, el = null;
    const parts = selector.split('>>>').map((s) => s.trim()).filter(Boolean);
    for (let i = 0; i < parts.length; i++) {
      const forced = /^(shadow|frame):/.test(parts[i]);
      const query = forced ? parts[i].slice(parts[i].indexOf(':') + 1).trim() : parts[i];
      el = root.querySelector(query);
      if (!el) return null;
      if (i === parts.length - 1) return el;
      // Pierce when this part demanded it, or when the next part names a shadow/frame child.
      const nextForced = /^(shadow|frame):/.test(parts[i + 1]);
      root = (forced || nextForced) ? (el.shadowRoot || frameDoc(el) || el) : el;
    }
    return el;
  };

  if (cmd === 'snapshot') {
    document.querySelectorAll('[data-ca]').forEach((e) => e.removeAttribute('data-ca'));
    const lines = [], selects = [], overlays = [], frames = [], shadows = [];
    let n = 0;
    walk(document.body || document.documentElement, (el, prefix) => {
      const r = el.getBoundingClientRect();
      if (el.matches(CA_SEL) && shown(el) && n < 400) {
        el.setAttribute('data-ca', n);
        const inView = r.bottom > 0 && r.top < innerHeight ? '' : ' (offscreen)';
        lines.push(`[${n}] ${prefix}${kindOf(el)} "${labelOf(el)}"${el.href ? ' -> ' + el.href : ''}${inView}`);
        n++;
      }
      if (el.tagName === 'SELECT') {
        const opts = [...el.options].map((o) => `${o.value}:${clean(o.text)}${o.selected ? '*' : ''}${o.disabled ? '!' : ''}`).join(' | ');
        selects.push(`select "${labelOf(el)}" value=${el.value} options: ${opts}`);
      }
      const role = el.getAttribute('role') || '';
      const isOverlay = (el.tagName === 'DIALOG' && el.open) || (el.matches(':popover-open')) || ['dialog', 'menu', 'listbox', 'alertdialog'].includes(role);
      if (isOverlay && shown(el)) overlays.push(`${el.tagName.toLowerCase()}${role ? `[${role}]` : ''} "${clean(el.innerText || el.textContent).slice(0, 200)}" ${Math.round(r.width)}x${Math.round(r.height)} at (${Math.round(r.x)},${Math.round(r.y)})`);
      if (el.shadowRoot) shadows.push(`${kindOf(el)}#${el.id || ''} has ${el.shadowRoot.querySelectorAll('*').length} shadow nodes`);
      if (el.tagName === 'IFRAME') {
        const d = frameDoc(el);
        if (d) frames.push(`iframe#${el.id || ''} "${clean(el.title)}" ${location.href !== (el.contentWindow && el.contentWindow.location.href) ? el.contentWindow.location.href : ''}`);
      }
    });
    // innerText drops top-layer (dialog/popover), shadow and frame text; collect visible text nodes.
    const parts = [];
    let scanned = 0;
    walk(document.body || document.documentElement, (el) => {
      if (++scanned > 3000 || SKIP_TEXT.test(el.tagName) || !shown(el)) return;
      for (const node of el.childNodes) if (node.nodeType === 3 && clean(node.nodeValue)) parts.push(clean(node.nodeValue));
    });
    const text = (parts.join('\n') || (document.body && document.body.innerText) || '').slice(0, Number(dy) || 15000);
    return { title: document.title, url: location.href, scrollY: Math.round(scrollY), pageHeight: document.documentElement.scrollHeight, text, elements: lines.join('\n'), overlays: overlays.join('\n'), selects: selects.join('\n'), frames: frames.join('\n'), shadows: shadows.join('\n') };
  }

  if (cmd === 'scroll') { scrollBy(0, dy); return `scrolled to y=${Math.round(scrollY)}`; }
  const el = resolve();
  if (cmd === 'locate') {
    if (!el) return null;
    el.scrollIntoView({ block: 'center', inline: 'center' });
    const r = el.getBoundingClientRect();
    return { x: Math.round(r.left + Math.min(r.width / 2, 40)), y: Math.round(r.top + r.height / 2) };
  }
  if (!el) return { error: `element not found (${selector || 'ref ' + ref}); call read_page again` };
  el.scrollIntoView({ block: 'center' });
  if (cmd === 'click') {
    const r = el.getBoundingClientRect();
    const init = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 };
    el.dispatchEvent(new PointerEvent('pointerover', { ...init, pointerId: 1, pointerType: 'mouse', isPrimary: true }));
    el.dispatchEvent(new MouseEvent('mouseover', init));
    el.dispatchEvent(new PointerEvent('pointerdown', { ...init, pointerId: 1, pointerType: 'mouse', isPrimary: true, buttons: 1 }));
    el.dispatchEvent(new MouseEvent('mousedown', { ...init, buttons: 1 }));
    el.dispatchEvent(new PointerEvent('pointerup', { ...init, pointerId: 1, pointerType: 'mouse', isPrimary: true }));
    el.dispatchEvent(new MouseEvent('mouseup', init));
    el.click();
    return 'clicked';
  }
  if (el.type === 'password') return { error: 'password fields are typed by the user: call ask_user with this field' };
  el.focus();
  if (el.tagName === 'SELECT') {
    const opt = [...el.options].find((o) => o.value === text || clean(o.text).toLowerCase() === clean(text).toLowerCase());
    if (!opt) return { error: `no option "${text}" in this select; read_page lists its options` };
    const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set;
    setter.call(el, opt.value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return `selected ${opt.value}`;
  }
  if (el.isContentEditable) {
    document.execCommand('selectAll', false);
    document.execCommand('insertText', false, text);
  } else {
    // Native setter so React/Vue controlled inputs see the change.
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, text);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  if (submit) {
    for (const t of ['keydown', 'keypress', 'keyup']) el.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    if (el.form) el.form.requestSubmit ? el.form.requestSubmit() : el.form.submit();
  }
  return 'typed';
}

async function inPage(tabId, func, args, world = 'ISOLATED') {
  noFile((await chrome.tabs.get(tabId)).url);
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, func, args, world });
  return r.result;
}

// ---- the agent's own pointer and question card (agent-ui.js, injected into the page) ----
const pointer = new Map(); // tabId -> last pointer position, so it glides on from there after a reload
async function ui(tabId, method, ...args) {
  const target = { tabId };
  await chrome.scripting.executeScript({ target, files: ['agent-ui.js'] });
  const [r] = await chrome.scripting.executeScript({ target, func: (m, a) => globalThis.__chromiagentUI[m](...a), args: [method, args] });
  return r.result;
}
async function pointTo(tabId, x, y, label) {
  try {
    const p = await ui(tabId, 'move', x, y, label, pointer.get(tabId));
    if (p) pointer.set(tabId, p);
  } catch {} // chrome://, the web store, or a closed tab: act without the pointer
}
const pressAt = (tabId) => ui(tabId, 'press').catch(() => {});
async function pointAtElement(tabId, ref, selector, label) {
  const p = await inPage(tabId, pageCmd, ['locate', ref ?? null, selector ?? null]);
  if (p) await pointTo(tabId, p.x, p.y, label);
  return p;
}
chrome.tabs.onRemoved.addListener((tabId) => {
  pointer.delete(tabId);
  if (tabId === boundTab) setBound(null);
});

const ANSWERS = {
  text: (v) => `The user answered: ${v}`,
  option: (v) => `The user chose: ${v}`,
  done: () => 'The user filled the field themselves and pressed Done. Its value is not shared with you; read_page to see the next step.',
  cancel: () => 'The user cancelled the question.',
  timeout: () => 'No answer after 10 minutes.',
};
const answerText = (r) => {
  if (r?.type === 'error') throw new Error(r.value);
  return (ANSWERS[r?.type] || ANSWERS.cancel)(r?.value);
};

// An explicitly selected tab stays selected across panel/extension reloads. The agent operates on
// that tab without changing the user's current window or stealing focus.
let boundTab = null;
let lastWebTab = null;
const isWebTab = (t) => !!t && /^https?:/i.test(t.url || '');
chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId).then((t) => { if (isWebTab(t)) lastWebTab = tabId; }).catch(() => {});
});
(async () => {
  try {
    const tabs = await chrome.tabs.query({});
    const web = tabs.filter(isWebTab);
    lastWebTab = (web.find((t) => t.active) || web[web.length - 1])?.id ?? null;
  } catch {}
})();
async function activeTab() {
  const [front] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (isWebTab(front)) return front.id;
  const { windowId } = await panelReady;
  const [tab] = await chrome.tabs.query({ active: true, windowId });
  if (isWebTab(tab)) return tab.id;
  // The front page is not a web page (the panel itself as a tab, chrome://extensions, DevTools):
  // fall back to the most recent web tab instead of failing every tool with "manifest must request permission".
  if (lastWebTab != null) {
    try { const t = await chrome.tabs.get(lastWebTab); if (isWebTab(t)) return lastWebTab; } catch { lastWebTab = null; }
  }
  const webs = (await chrome.tabs.query({ windowId })).filter(isWebTab);
  if (webs.length) return webs[webs.length - 1].id;
  throw new Error('no web page is open in this window: open the page you want me to work on first');
}
async function setBound(tabId) {
  boundTab = tabId ?? null;
  try {
    const { windowId } = await panelReady;
    const key = `bound:${windowId}`;
    if (boundTab == null) await chrome.storage.local.remove(key);
    else await chrome.storage.local.set({ [key]: boundTab });
  } catch {} // storage may be unavailable on restricted or older extension installs
}
async function getBound() {
  if (boundTab != null) return boundTab;
  try {
    const { windowId } = await panelReady;
    const key = `bound:${windowId}`;
    const id = (await chrome.storage.local.get(key))[key];
    if (typeof id === 'number') { await chrome.tabs.get(id); boundTab = id; return id; }
    if (id != null) await chrome.storage.local.remove(key);
  } catch { await setBound(null); }
  return null;
}
async function focusTab(tabId) {
  const tab = await chrome.tabs.get(tabId);
  const win = await chrome.windows.get(tab.windowId);
  if (win.state === 'minimized') await chrome.windows.update(win.id, { state: 'normal' });
  await chrome.tabs.update(tabId, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true });
  return tab;
}
// Explicit tabId wins; otherwise pin the active page on the first action, then keep working there
// while the user switches windows or tabs.
async function tabArg(args = {}) {
  const explicit = args.tabId != null;
  let id = explicit ? args.tabId : await getBound();
  if (id == null) { id = await activeTab(); await setBound(id); }
  try { await chrome.tabs.get(id); }
  catch {
    if (explicit) throw new Error(`tab ${id} is gone; call list_tabs`);
    await setBound(null);
    id = await activeTab();
    await setBound(id);
  }
  if (explicit) await setBound(id);
  return id;
}

const tools = {
  async list_tabs() {
    const mine = await mineSet();
    const bound = await getBound();
    const tabs = await chrome.tabs.query({});
    return tabs.map((t) => ({ tabId: t.id, windowId: t.windowId, active: t.active, title: t.title, url: t.url, mine: mine.has(t.id) || undefined, bound: t.id === bound || undefined, audible: t.audible || undefined, pinned: t.pinned || undefined }));
  },
  async bind_tab({ tabId }) {
    const t = await chrome.tabs.get(tabId);
    await setBound(tabId);
    return `selected "${t.title}" (${t.url}); I'll keep working in this tab without switching your window until you bind another tab or call unbind_tab`;
  },
  async unbind_tab() {
    await setBound(null);
    return 'tab selection cleared; following the active page';
  },
  async activate_tab({ tabId }) {
    const t = await focusTab(tabId);
    await setBound(tabId);
    return `active: ${t.title}`;
  },
  async open_tab({ url, active = false }) {
    noFile(url);
    // Work tabs open in the background by default so the agent does not take over the user's screen.
    const t = await chrome.tabs.create({ url, active: !!active });
    await markMine(t.id);
    await setBound(t.id);
    return { tabId: t.id, windowId: t.windowId, active: !!active };
  },
  async close_tab({ tabId }) {
    await chrome.tabs.remove(tabId);
    if (tabId === boundTab) await setBound(null);
    return 'closed';
  },
  async navigate({ tabId, url, action }) {
    noFile(url);
    if (url) await chrome.tabs.update(tabId, { url });
    else if (action === 'back') await chrome.tabs.goBack(tabId);
    else if (action === 'forward') await chrome.tabs.goForward(tabId);
    else if (action === 'reload') await chrome.tabs.reload(tabId);
    else throw new Error('give url or action');
    await waitLoaded(tabId);
    const t = await chrome.tabs.get(tabId);
    return { title: t.title, url: t.url };
  },
  read_page: ({ tabId, maxChars }) => inPage(tabId, pageCmd, ['snapshot', null, null, null, false, maxChars || 15000]),
  async click({ tabId, ref, selector }) {
    const p = await pointAtElement(tabId, ref, selector, 'click');
    if (!p) return { error: `element not found (${selector || 'ref ' + ref}); call read_page again` };
    await pressAt(tabId);
    return inPage(tabId, pageCmd, ['click', ref ?? null, selector ?? null, null, false, 0]);
  },
  async type({ tabId, ref, selector, text, submit }) {
    await pointAtElement(tabId, ref, selector, 'typing');
    return inPage(tabId, pageCmd, ['type', ref ?? null, selector ?? null, text, !!submit, 0]);
  },
  async scroll({ tabId, dy }) {
    const p = await inPage(tabId, () => ({ x: Math.round(innerWidth * 0.72), y: Math.round(innerHeight * 0.78) }));
    await pointTo(tabId, p.x, p.y, 'scrolling');
    return inPage(tabId, pageCmd, ['scroll', null, null, null, false, dy]);
  },
  // The pointer's human arc, for drags and chess moves: scan a friendly piece or two, glide in, dwell,
  // press, glide out, rest nearby. Runs through the extension so the pointer is what the user sees.
  async pointer_stroke({ tabId, from, to, decoys, color, label }) {
    if (!from || !to) throw new Error('pointer_stroke needs from and to ({ x, y } each)');
    const num = (v) => Number(v);
    const args = [num(from.x), num(from.y), num(to.x), num(to.y), { decoys: Math.min(2, Math.max(0, num(decoys) || 0)), color: color || null, label: label || null }];
    return ui(tabId, 'stroke', ...args);
  },
  press_key: ({ tabId, key }) => inPage(tabId, (k) => {
    // Synthetic DOM key events: no debugger, no "debugging this browser" bar. Sites that read
    // key/code/keyCode from handlers get exactly what a browser emits for a key press.
    const KEYV = { Enter: 13, Tab: 9, Escape: 27, Backspace: 8, Delete: 46, Space: 32, ' ': 32, ArrowUp: 38, ArrowDown: 40, ArrowLeft: 37, ArrowRight: 39, PageUp: 33, PageDown: 34, Home: 36, End: 35 };
    const code = KEYV[k] ?? (k.length === 1 ? k.toUpperCase().charCodeAt(0) : 0);
    const codeName = k === ' ' ? 'Space' : k;
    const target = document.activeElement && document.activeElement !== document.body ? document.activeElement : (document.body || document.documentElement);
    const init = { key: k === ' ' ? ' ' : k, code: codeName, keyCode: code, which: code, bubbles: true, cancelable: true, composed: true };
    target.dispatchEvent(new KeyboardEvent('keydown', init));
    if (k.length === 1) target.dispatchEvent(new KeyboardEvent('keypress', init));
    target.dispatchEvent(new KeyboardEvent('keyup', init));
    return 'pressed ' + k;
  }, [key]),
  run_js: ({ tabId, code }) => inPage(tabId, (src) => {
    // Runs in the page's main world (page globals visible) and bypasses page CSP — no debugger involved.
    // Always returns the JSON-encoded value, so scripts get a predictable string.
    const AsyncFn = Object.getPrototypeOf(async function () {}).constructor;
    return Promise.resolve()
      .then(() => new AsyncFn(src)())
      .then((v) => JSON.stringify(v === undefined ? null : v) ?? 'null')
      .catch((e) => { throw new Error(String((e && e.message) || e)); });
  }, [code], 'MAIN'),
  // A question next to the agent's pointer; with ref/selector the user fills that field on the page.
  async ask_user({ tabId, question, options, placeholder, ref, selector }) {
    const { windowId } = await panelReady;
    // No bound tab: the card opens in the panel, never on whatever the user happens to be looking at.
    const tab = tabId ? await chrome.tabs.get(tabId).catch(() => null) : null;
    const field = ref != null || !!selector;
    if (!tab || !/^https?:/i.test(tab.url || '')) {
      if (field) throw new Error('fields can only be filled on a web page: bind_tab the page with the field');
      return answerText(await panelAsk({ question, options, placeholder }));
    }
    // Never pulls the user over: a question about a tab they are not looking at opens in the panel,
    // and a field to fill waits on its page while the panel and the toolbar icon say where.
    if (!field && !(await inView(tab))) return answerText(await withBadge(panelAsk({ question, options, placeholder })));
    if (field && !(await pointAtElement(tab.id, ref, selector, 'your turn'))) throw new Error('field not found; call read_page again');
    const waiting = ui(tab.id, 'ask', { question, options: options || [], placeholder, ref, selector });
    const away = field && !(await inView(tab)) ? panelNotice(`${question}\nOn the tab "${tab.title}".`, tab) : null;
    try {
      return answerText(await (away ? withBadge(waiting) : waiting));
    } catch (e) {
      // Pressing Enter in a login form usually submits it and loads a new page.
      if (field && /frame|navigat|closed|No tab/i.test(e.message)) return 'The page changed while the user was filling the field (they probably submitted it). Call read_page to check.';
      throw e;
    } finally {
      away?.();
    }
  },
  async screenshot({ tabId }) {
    const frames = await frameSource(tabId);
    try { return { image: (await frames.grab()).split(',')[1] }; } finally { await frames.done(); }
  },
  // A continuous stream of everything that happens on a tab (see recorder.js).
  async monitor({ tabId, action = 'start' }) {
    if (action === 'stop') { monitors.delete(tabId); return 'stopped'; }
    const tab = await chrome.tabs.get(tabId);
    noFile(tab.url);
    if (!monitors.has(tabId)) monitors.set(tabId, { started: Date.now(), since: 0, rid: null, queue: [] });
    await injectRecorder(tabId);
    return `monitoring tab ${tabId}: ${tab.title} (${tab.url}). Call events to receive what happens.`;
  },
  // Returns as soon as something happens (or after waitMs with an empty list).
  async events({ tabId, waitMs = 15000, max = 150 }) {
    if (!monitors.has(tabId)) await tools.monitor({ tabId });
    const m = monitors.get(tabId);
    const end = Date.now() + Math.min(Math.max(waitMs, 0), 110000);
    for (;;) {
      let page = null;
      try {
        [{ result: page }] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', args: [m.since, m.rid],
          func: (since, rid) => { const r = window.__chromiagentRec; return r ? r.take(r.id === rid ? since : 0) : null; } });
      } catch {} // between two pages, or a page we may not enter
      if (page === null) await injectRecorder(tabId).catch(() => {});
      const out = m.queue.splice(0);
      if (page) {
        m.rid = page.id;
        if (page.events.length) m.since = page.events[page.events.length - 1].seq;
        out.push(...page.events);
        if (page.dropped) out.push({ t: Date.now(), type: 'dropped', count: page.dropped });
      }
      if (out.length || Date.now() >= end) {
        out.sort((a, b) => a.t - b.t);
        const shown = out.slice(-max).map(({ seq, t, ...e }) => ({ at: +((t - m.started) / 1000).toFixed(2), ...e }));
        const tab = await chrome.tabs.get(tabId).catch(() => null);
        return { tabId, url: tab?.url, title: tab?.title, skipped: out.length - shown.length, events: shown };
      }
      await sleep(300);
    }
  },
  // Watches a tab like a short video: frames over time, merged into one timeline image.
  // untilChange / untilText return the moment it happens, so the agent can react in a see-act loop.
  async watch({ tabId, seconds = 6, untilChange = false, untilText }) {
    const source = await frameSource(tabId);
    const sees = async () => (await chrome.scripting.executeScript({ target: { tabId }, func: (s) => !!document.body?.innerText.includes(s), args: [untilText] }))[0].result;
    let found = false;
    const t0 = Date.now(), end = t0 + Math.min(Math.max(seconds, 1), 30) * 1000;
    const frames = [];
    let last = null, captured = 0;
    try {
      while (Date.now() < end) {
        const shot = Date.now();
        const url = await source.grab();
        captured++;
        // Same pixels encode to the same bytes: only frames where something moved are kept.
        if (url !== last) frames.push({ url, at: (Date.now() - t0) / 1000 });
        last = url;
        if (untilChange && frames.length > 1) break;
        if (untilText && (found = await sees().catch(() => false))) break;
        await sleep(Math.max(0, 510 - (Date.now() - shot))); // Chrome allows two captures per second
      }
    } finally {
      await source.done();
    }
    const image = await timeline(frames.length > WATCH_MAX ? pickEvenly(frames, WATCH_MAX) : frames);
    const changes = frames.slice(1).map((f) => `+${f.at.toFixed(1)}s`).join(', ');
    const text = untilText && !found ? `"${untilText}" did not appear in ${seconds}s (${captured} frames).`
      : untilChange && frames.length < 2 ? `Nothing changed in ${seconds}s (${captured} frames).`
      : (found ? `"${untilText}" appeared. ` : '') + `${captured} frames over ${((Date.now() - t0) / 1000).toFixed(1)}s; the picture changed ${frames.length - 1} time${frames.length === 2 ? '' : 's'}${changes ? ` (at ${changes})` : ''}. The image shows the distinct frames in order, left to right, top to bottom.`;
    return { image, text };
  },
};

// Tabs the agent opens itself, recorded so list_tabs can mark them — no groups, no visible markings.
const mineKey = 'ca_mine';
async function mineSet() {
  try { return new Set((await chrome.storage.session.get(mineKey))[mineKey] || []); } catch { return new Set(); }
}
async function markMine(id) {
  try { const a = (await chrome.storage.session.get(mineKey))[mineKey] || []; await chrome.storage.session.set({ [mineKey]: [...new Set([...a, id])].slice(-300) }); } catch {}
}
async function unmarkMine(id) {
  try { const a = (await chrome.storage.session.get(mineKey))[mineKey] || []; await chrome.storage.session.set({ [mineKey]: a.filter((x) => x !== id) }); } catch {}
}
chrome.tabs.onRemoved.addListener((id) => { unmarkMine(id); });
// One-time cleanup of the green "Chromiagent" group (1.12–1.14): those tabs become ordinary tabs.
(async () => {
  try {
    if (!chrome.tabGroups) return;
    for (const g of await chrome.tabGroups.query({ title: 'Chromiagent' })) {
      const tabs = await chrome.tabs.query({ groupId: g.id });
      if (tabs.length) await chrome.tabs.ungroup(tabs.map((t) => t.id));
    }
  } catch {}
})();

// A tab the user can see right now: the selected tab of the focused, not minimized window.
async function inView(tab) {
  const win = await chrome.windows.get(tab.windowId);
  return tab.active && win.focused && win.state !== 'minimized';
}

// Frames of a tab. A tab the user sees (window focused, not minimized) is captured as shown, with no
// debugger. A background tab renders off screen only through the debugger: it is attached for the
// capture and detached right away, so the debug bar shows only while the capture runs.
async function frameSource(tabId) {
  const tab = await chrome.tabs.get(tabId);
  noFile(tab.url);
  // The agent's own glow and pointer are hidden meanwhile: they would show up as changes in every frame.
  const overlays = (shown) => chrome.scripting.executeScript({ target: { tabId }, args: [shown],
    func: (v) => ['__chromiagent-glow', '__chromiagent-ui'].forEach((id) => { const e = document.getElementById(id); if (e) e.style.visibility = v ? '' : 'hidden'; }) }).catch(() => {});
  await overlays(false);
  if (await inView(tab)) {
    return { grab: () => chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 55 }), done: () => overlays(true) };
  }
  const target = { tabId };
  const own = !cdp.attachedTabs.has(tabId);
  if (own) await chrome.debugger.attach(target, '1.3');
  return {
    grab: async () => `data:image/jpeg;base64,${(await chrome.debugger.sendCommand(target, 'Page.captureScreenshot', { format: 'jpeg', quality: 55 })).data}`,
    done: async () => { if (own) await chrome.debugger.detach(target).catch(() => {}); await overlays(true); },
  };
}

// A "?" on the toolbar icon while the agent waits for the user, so it shows in every window.
async function withBadge(promise) {
  chrome.action.setBadgeBackgroundColor({ color: '#39ff14' });
  chrome.action.setBadgeText({ text: '?' });
  try { return await promise; } finally { chrome.action.setBadgeText({ text: '' }); }
}

// ---- monitoring state; the recorder is put back after every navigation ----
const monitors = new Map(); // tabId -> { started, since, rid, queue }
const injectRecorder = (tabId) => chrome.scripting.executeScript({ target: { tabId }, files: ['recorder.js'], world: 'MAIN', injectImmediately: true });
chrome.tabs.onUpdated.addListener((tabId, change) => {
  const m = monitors.get(tabId);
  if (!m) return;
  if (change.url) m.queue.push({ t: Date.now(), type: 'tab', change: 'url', url: change.url });
  if (change.status) m.queue.push({ t: Date.now(), type: 'tab', change: change.status });
  if (change.audible !== undefined) m.queue.push({ t: Date.now(), type: 'tab', change: change.audible ? 'sound on' : 'sound off' });
  if (change.status === 'complete') injectRecorder(tabId).catch(() => {});
});
chrome.tabs.onCreated.addListener((tab) => {
  monitors.get(tab.openerTabId)?.queue.push({ t: Date.now(), type: 'tab', change: 'opened a new tab', tabId: tab.id, url: tab.pendingUrl || tab.url });
});
chrome.tabs.onRemoved.addListener((tabId) => {
  const m = monitors.get(tabId);
  if (m) m.queue.push({ t: Date.now(), type: 'tab', change: 'closed' });
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const WATCH_MAX = 12;
const pickEvenly = (a, n) => Array.from({ length: n }, (_, i) => a[Math.round((i * (a.length - 1)) / (n - 1))]);

// Lays frames out in a grid, each stamped with its time, and returns base64 JPEG.
async function timeline(frames) {
  // Decoded by hand: the panel's CSP does not let fetch() read data: URLs.
  const blob = (url) => new Blob([Uint8Array.from(atob(url.slice(url.indexOf(',') + 1)), (c) => c.charCodeAt(0))], { type: 'image/jpeg' });
  const bitmaps = await Promise.all(frames.map((f) => createImageBitmap(blob(f.url))));
  const cols = Math.min(3, bitmaps.length), rows = Math.ceil(bitmaps.length / cols);
  const w = bitmaps.length === 1 ? Math.min(bitmaps[0].width, 1280) : 480;
  const h = Math.round((w * bitmaps[0].height) / bitmaps[0].width), gap = 6;
  const canvas = new OffscreenCanvas(cols * w + (cols - 1) * gap, rows * h + (rows - 1) * gap);
  const g = canvas.getContext('2d');
  g.fillStyle = '#131314';
  g.fillRect(0, 0, canvas.width, canvas.height);
  g.font = 'bold 15px sans-serif';
  bitmaps.forEach((b, i) => {
    const x = (i % cols) * (w + gap), y = Math.floor(i / cols) * (h + gap);
    g.drawImage(b, x, y, w, h);
    const label = `${i + 1} · +${frames[i].at.toFixed(1)}s`;
    g.fillStyle = 'rgba(0,0,0,.75)';
    g.fillRect(x + 6, y + 6, g.measureText(label).width + 14, 24);
    g.fillStyle = '#39ff14';
    g.fillText(label, x + 13, y + 23);
  });
  const bytes = new Uint8Array(await (await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.7 })).arrayBuffer());
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

async function waitLoaded(tabId, ms = 15000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if ((await chrome.tabs.get(tabId)).status === 'complete') return;
    await new Promise((r) => setTimeout(r, 250));
  }
}

// Every tool that acts on a page: it gets the agent's bound tab when no tabId is given.
const TABBED = new Set(['activate_tab', 'close_tab', 'navigate', 'read_page', 'click', 'type', 'press_key', 'scroll', 'run_js', 'screenshot', 'monitor', 'events', 'watch', 'ask_user', 'pointer_stroke']);

async function connectBridge() {
  const ws = new WebSocket(`ws://127.0.0.1:17371/bridge?panel=${(await panelReady).id}`);
  ws.onopen = () => panelReady.then(({ id }) => console.info(`[chromiagent] bridge connected; panel=${id}`));
  ws.onerror = (e) => console.error('[chromiagent] bridge websocket error', e);
  ws.onmessage = async (e) => {
    const msg = JSON.parse(e.data);
    if (msg.cdpOpen) return cdp.open((m) => ws.readyState === WebSocket.OPEN && ws.send(JSON.stringify({ cdp: m })));
    if (msg.cdpClose) { console.info('[chromiagent] playwright disconnected'); return cdp.close(); }
    if (msg.cdp) return cdp.message(msg.cdp);
    const { id, tool, args } = msg;
    let out;
    try {
      if (!tools[tool]) throw new Error(`unknown tool ${tool}`);
      const a = TABBED.has(tool) ? { ...(args || {}), tabId: await tabArg(args || {}) } : { ...(args || {}) };
      if (tool === 'ask_user' && a.tabId == null && boundTab != null) a.tabId = boundTab;
      if (!['watch', 'screenshot', 'monitor', 'events'].includes(tool)) await glow(a?.tabId); // show the active page before acting
      const r = await tools[tool](a);
      if (tool === 'open_tab') await glow(r.tabId);
      out = r && r.image ? { id, image: r.image, result: r.text } : r && r.error ? { id, error: r.error } : { id, result: r };
    } catch (err) {
      console.error(`[chromiagent] ${tool} failed on tab ${args?.tabId ?? 'active'}:`, err);
      out = { id, error: String(err.message || err) };
    }
    ws.send(JSON.stringify(out));
  };
  ws.onclose = () => { console.info('[chromiagent] bridge closed'); cdp.close(); setTimeout(connectBridge, 2000); };
}
connectBridge();
